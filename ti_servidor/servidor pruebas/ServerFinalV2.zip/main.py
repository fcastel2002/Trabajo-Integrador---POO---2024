from InterfazConsola import InterfazConsola

def main():
    consola = InterfazConsola()
    consola.iniciar()

if __name__ == "__main__":

    main()