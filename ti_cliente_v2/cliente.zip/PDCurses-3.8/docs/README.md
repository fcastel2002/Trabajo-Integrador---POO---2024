PDCurses Web Site
=================

This directory contains the files for https://pdcurses.org/ . The main
documentation for PDCurses is now in [man].

[man]: ../man/README.md
